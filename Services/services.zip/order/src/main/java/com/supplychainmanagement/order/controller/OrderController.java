package com.supplychainmanagement.order.controller;

import com.supplychainmanagement.order.entity.Order;
import com.supplychainmanagement.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/order")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @PostMapping("/placeorder")
    public Order placeOrder(@RequestBody Order order){
        return orderService.placeOrder(order);
    }

    @GetMapping("/findallorders")
    public List<Order> getAllOrders(){
        return orderService.getAllOrders();
    }

    @GetMapping("/getorderbyid/{id}")
    public Order getOrderById(@PathVariable("id") String orderId){
        return orderService.getOrderById(orderId);
    }

    @PutMapping("/update/{id}")
    public Order updateOrderById(@PathVariable("id")String orderId,@RequestBody Order order){
        return orderService.updateOrderById(orderId,order);
    }
}
