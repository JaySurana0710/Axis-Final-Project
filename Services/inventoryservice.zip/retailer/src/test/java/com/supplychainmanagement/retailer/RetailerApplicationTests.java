package com.supplychainmanagement.retailer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailerApplicationTests {

	@Test
	void contextLoads() {
	}

}
